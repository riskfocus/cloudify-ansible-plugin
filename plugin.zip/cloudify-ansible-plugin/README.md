cloudify-ansible-plugin
========================

### Please note this plugin is under development and not yet officially supported. Use with Care!

The Ansible plugin can be used to run Ansible Playbooks against a single node in a Cloudify Blueprint.

## Usage

See [Ansible Plugin](http://getcloudify.org/guide/3.2/plugins-ansible.html)
